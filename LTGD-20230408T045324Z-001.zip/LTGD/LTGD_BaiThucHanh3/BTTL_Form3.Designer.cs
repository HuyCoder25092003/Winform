﻿namespace LTGD_BaiThucHanh3
{
    partial class BTTL_Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtCenterX = new System.Windows.Forms.TextBox();
            this.txtCenterY = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtRadius = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtOtherX = new System.Windows.Forms.TextBox();
            this.txtOtherY = new System.Windows.Forms.TextBox();
            this.lbResult = new System.Windows.Forms.Label();
            this.lbArea = new System.Windows.Forms.Label();
            this.lbPerimeter = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.btnXemKQ = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(189, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(190, 38);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tọa độ tâm:";
            // 
            // txtCenterX
            // 
            this.txtCenterX.Location = new System.Drawing.Point(445, 46);
            this.txtCenterX.Name = "txtCenterX";
            this.txtCenterX.Size = new System.Drawing.Size(100, 45);
            this.txtCenterX.TabIndex = 0;
            // 
            // txtCenterY
            // 
            this.txtCenterY.Location = new System.Drawing.Point(603, 46);
            this.txtCenterY.Name = "txtCenterY";
            this.txtCenterY.Size = new System.Drawing.Size(100, 45);
            this.txtCenterY.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(295, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(153, 38);
            this.label2.TabIndex = 0;
            this.label2.Text = "Bán kính:";
            // 
            // txtRadius
            // 
            this.txtRadius.Location = new System.Drawing.Point(498, 110);
            this.txtRadius.Name = "txtRadius";
            this.txtRadius.Size = new System.Drawing.Size(100, 45);
            this.txtRadius.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(186, 185);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(181, 38);
            this.label3.TabIndex = 0;
            this.label3.Text = "Điểm khác:";
            // 
            // txtOtherX
            // 
            this.txtOtherX.Location = new System.Drawing.Point(440, 182);
            this.txtOtherX.Name = "txtOtherX";
            this.txtOtherX.Size = new System.Drawing.Size(100, 45);
            this.txtOtherX.TabIndex = 3;
            // 
            // txtOtherY
            // 
            this.txtOtherY.Location = new System.Drawing.Point(606, 182);
            this.txtOtherY.Name = "txtOtherY";
            this.txtOtherY.Size = new System.Drawing.Size(100, 45);
            this.txtOtherY.TabIndex = 4;
            // 
            // lbResult
            // 
            this.lbResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbResult.Location = new System.Drawing.Point(242, 294);
            this.lbResult.Name = "lbResult";
            this.lbResult.Size = new System.Drawing.Size(409, 62);
            this.lbResult.TabIndex = 2;
            this.lbResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbArea
            // 
            this.lbArea.AutoSize = true;
            this.lbArea.Location = new System.Drawing.Point(235, 373);
            this.lbArea.Name = "lbArea";
            this.lbArea.Size = new System.Drawing.Size(153, 38);
            this.lbArea.TabIndex = 2;
            this.lbArea.Text = "Diện tích:";
            // 
            // lbPerimeter
            // 
            this.lbPerimeter.AutoSize = true;
            this.lbPerimeter.Location = new System.Drawing.Point(235, 422);
            this.lbPerimeter.Name = "lbPerimeter";
            this.lbPerimeter.Size = new System.Drawing.Size(119, 38);
            this.lbPerimeter.TabIndex = 2;
            this.lbPerimeter.Text = "Chu vi:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(391, 49);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 38);
            this.label7.TabIndex = 0;
            this.label7.Text = "X:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(550, 49);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 38);
            this.label8.TabIndex = 0;
            this.label8.Text = "Y:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(382, 185);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 38);
            this.label9.TabIndex = 0;
            this.label9.Text = "X:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(549, 185);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 38);
            this.label10.TabIndex = 0;
            this.label10.Text = "Y:";
            // 
            // btnXemKQ
            // 
            this.btnXemKQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXemKQ.Location = new System.Drawing.Point(346, 238);
            this.btnXemKQ.Name = "btnXemKQ";
            this.btnXemKQ.Size = new System.Drawing.Size(200, 49);
            this.btnXemKQ.TabIndex = 5;
            this.btnXemKQ.Text = "Xem kết quả";
            this.btnXemKQ.UseVisualStyleBackColor = true;
            this.btnXemKQ.Click += new System.EventHandler(this.BtnXemKQ_Click);
            // 
            // BTTL_Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 38F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(893, 469);
            this.Controls.Add(this.btnXemKQ);
            this.Controls.Add(this.lbPerimeter);
            this.Controls.Add(this.lbArea);
            this.Controls.Add(this.lbResult);
            this.Controls.Add(this.txtOtherY);
            this.Controls.Add(this.txtCenterY);
            this.Controls.Add(this.txtRadius);
            this.Controls.Add(this.txtOtherX);
            this.Controls.Add(this.txtCenterX);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(7);
            this.MaximizeBox = false;
            this.Name = "BTTL_Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BTTN_Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCenterX;
        private System.Windows.Forms.TextBox txtCenterY;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtRadius;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtOtherX;
        private System.Windows.Forms.TextBox txtOtherY;
        private System.Windows.Forms.Label lbResult;
        private System.Windows.Forms.Label lbArea;
        private System.Windows.Forms.Label lbPerimeter;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnXemKQ;
    }
}