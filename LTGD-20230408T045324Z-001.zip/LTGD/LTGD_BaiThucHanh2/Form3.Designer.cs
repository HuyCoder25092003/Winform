﻿namespace LTGD_BaiThucHanh2
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.lbSo1 = new System.Windows.Forms.Label();
            this.lbSo2 = new System.Windows.Forms.Label();
            this.lbSo3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rd11_18 = new System.Windows.Forms.RadioButton();
            this.rd3_10 = new System.Windows.Forms.RadioButton();
            this.bttnQuaySo = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.lbDiem = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbSo1
            // 
            this.lbSo1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbSo1.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSo1.Location = new System.Drawing.Point(125, 30);
            this.lbSo1.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbSo1.Name = "lbSo1";
            this.lbSo1.Size = new System.Drawing.Size(150, 166);
            this.lbSo1.TabIndex = 0;
            this.lbSo1.Text = "0";
            this.lbSo1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbSo2
            // 
            this.lbSo2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbSo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSo2.Location = new System.Drawing.Point(338, 30);
            this.lbSo2.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbSo2.Name = "lbSo2";
            this.lbSo2.Size = new System.Drawing.Size(150, 166);
            this.lbSo2.TabIndex = 0;
            this.lbSo2.Text = "0";
            this.lbSo2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbSo3
            // 
            this.lbSo3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbSo3.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSo3.Location = new System.Drawing.Point(551, 30);
            this.lbSo3.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbSo3.Name = "lbSo3";
            this.lbSo3.Size = new System.Drawing.Size(150, 166);
            this.lbSo3.TabIndex = 0;
            this.lbSo3.Text = "0";
            this.lbSo3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rd11_18);
            this.groupBox1.Controls.Add(this.rd3_10);
            this.groupBox1.ForeColor = System.Drawing.Color.Blue;
            this.groupBox1.Location = new System.Drawing.Point(125, 234);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(576, 121);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Chọn";
            // 
            // rd11_18
            // 
            this.rd11_18.Appearance = System.Windows.Forms.Appearance.Button;
            this.rd11_18.AutoSize = true;
            this.rd11_18.BackColor = System.Drawing.Color.WhiteSmoke;
            this.rd11_18.Location = new System.Drawing.Point(351, 49);
            this.rd11_18.Name = "rd11_18";
            this.rd11_18.Size = new System.Drawing.Size(110, 48);
            this.rd11_18.TabIndex = 1;
            this.rd11_18.Text = "11-18";
            this.rd11_18.UseVisualStyleBackColor = false;
            // 
            // rd3_10
            // 
            this.rd3_10.Appearance = System.Windows.Forms.Appearance.Button;
            this.rd3_10.AutoSize = true;
            this.rd3_10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.rd3_10.Checked = true;
            this.rd3_10.Location = new System.Drawing.Point(104, 49);
            this.rd3_10.Name = "rd3_10";
            this.rd3_10.Size = new System.Drawing.Size(92, 48);
            this.rd3_10.TabIndex = 0;
            this.rd3_10.TabStop = true;
            this.rd3_10.Text = "3-10";
            this.rd3_10.UseVisualStyleBackColor = false;
            // 
            // bttnQuaySo
            // 
            this.bttnQuaySo.ForeColor = System.Drawing.Color.Blue;
            this.bttnQuaySo.Location = new System.Drawing.Point(125, 407);
            this.bttnQuaySo.Name = "bttnQuaySo";
            this.bttnQuaySo.Size = new System.Drawing.Size(150, 53);
            this.bttnQuaySo.TabIndex = 0;
            this.bttnQuaySo.Text = "Quay số";
            this.bttnQuaySo.UseVisualStyleBackColor = true;
            this.bttnQuaySo.Click += new System.EventHandler(this.bttnQuaySo_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(424, 414);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 38);
            this.label4.TabIndex = 3;
            this.label4.Text = "Điểm:";
            // 
            // lbDiem
            // 
            this.lbDiem.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDiem.ForeColor = System.Drawing.Color.Red;
            this.lbDiem.Location = new System.Drawing.Point(551, 407);
            this.lbDiem.Name = "lbDiem";
            this.lbDiem.Size = new System.Drawing.Size(150, 53);
            this.lbDiem.TabIndex = 3;
            this.lbDiem.Text = "0";
            this.lbDiem.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 38F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(827, 488);
            this.Controls.Add(this.lbDiem);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.bttnQuaySo);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lbSo3);
            this.Controls.Add(this.lbSo2);
            this.Controls.Add(this.lbSo1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(7);
            this.MaximizeBox = false;
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Random Number V1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbSo1;
        private System.Windows.Forms.Label lbSo2;
        private System.Windows.Forms.Label lbSo3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rd11_18;
        private System.Windows.Forms.RadioButton rd3_10;
        private System.Windows.Forms.Button bttnQuaySo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbDiem;
    }
}